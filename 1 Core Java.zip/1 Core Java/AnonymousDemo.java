interface Age 
{
	int x = 21;
    void getAge();
}
class AnonymousClass implements Age 
{
 
    @Override public void getAge()
    {
        System.out.print("Age is " + x);
    }
}

class AnonymousDemo
	{
     public static void main(String[] args)
      {
        AnonymousClass obj = new AnonymousClass();
        obj.getAge();
      }
}