class ArrayRetDemo{
	public static void main(String args[])
	{
		int[] a={10,20,30};
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	for(int j:a)
	{
		System.out.println(j);
	}
	}
	
}
