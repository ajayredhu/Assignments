class RemDuplicateArr
{
	public static void main(String args[])
	{
		int rem=0;
		int[] a ={2,3,4,5,6,7,6,7,5};
		int[] b=new int[a.length];
		int count=0;
		int n=a.length;
		int x=0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					x=a[i];
					a[i]=a[j];
					a[j]=x;
				}
			}
		}
		System.out.println();
		for(int i=0;i<n-1;i++)
		{
			if(a[i]!=a[i+1])
			{
				b[count]=a[i];
				count++;
			}
		}
		b[count]=a[n-1];
		for(int i=0;i<=count;i++)
		{
			System.out.println(b[i]);
		}
	}
}
