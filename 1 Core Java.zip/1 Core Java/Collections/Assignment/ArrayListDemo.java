import java.util.ArrayList;
class ArrayListDemo
{
 public static void main(String args[])
 {
  ArrayList<String> a= new ArrayList<String>();
  a.add("Ajay ");
  a.add("Welcome ");
  a.add("to ");
  a.add("Yash ");
  for(String x : a)
  {
   System.out.print(x);
  }
 }
}