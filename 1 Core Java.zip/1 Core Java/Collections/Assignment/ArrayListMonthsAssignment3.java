import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Vector;

public class ArrayListMonthsAssignment3
{
 public static void main(String args[])
 {
  ArrayList<String> a1= new ArrayList<String>();
  a1.add("January");
  a1.add("February");
  a1.add("March");
  a1.add("April");
  a1.add("May");
  a1.add("June");
  a1.add("July");
  a1.add("August");
  a1.add("September");
  a1.add("October");
  a1.add("November");
  a1.add("December");
  
  System.out.println(a1);
  Vector<String> v1= new Vector<String>(a1);
 
 for(String x : v1)
		{
		System.out.println(x);
		}

  
 }
}