import java.util.HashSet;
import java.util.Iterator;

public class EmployeeSetAssignment2 
{

	public static void main(String[] args) 
	{
		HashSet<String> set = new HashSet<>();
		
		set.add("Ajay");
		set.add("Vikas");
		set.add("Rakesh");
		set.add("Jaynam");
		
		Iterator<String> it = set.iterator();
		while (it.hasNext())
		{
			System.out.println(it.next());
		}
	}

}