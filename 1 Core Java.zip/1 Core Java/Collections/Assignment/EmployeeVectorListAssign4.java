import java.util.Iterator;
import java.util.Vector;

class Employee 
{
	private int id;
	private String name;
	private String address;
	private Double salary;
	
	public Employee(int id, String name, String address, Double salary) 
	{
	
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}	
	
	public int getId() 
	{
		return id;
	}

	@Override
	public String toString() 
	{
		return "Employee [id="+id+",name="+name+",address="+address+",salary="+salary+"]";
	}
}

public class EmployeeVectorListAssign4 
{
	public static void main(String[] args) 
	{
		Vector<Employee> list = new Vector<>();
		
		list.add(new Employee(101, "Ajay", "24 Indore, India", 200000.8));
		list.add(new Employee(102, "Dhaval", "26 Indore, India", 30000.9));
		list.add(new Employee(103, "Chirag", "27 Indore, India", 25000.6));
		list.add(new Employee(104, "Alok", "28 Indore, India", 40000.2));
		
		Iterator<Employee> it = list.iterator();
		while (it.hasNext()) 
			System.out.println(it.next());
		

	}

}