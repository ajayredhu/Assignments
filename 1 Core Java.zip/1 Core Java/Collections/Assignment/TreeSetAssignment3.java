import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetAssignment3 
{
	public static void main(String[] args) 
	{
		TreeSet<String> set = new TreeSet<>();
		
		set.add("Ajay");
		set.add("Chirag");
		set.add("Dhaval");
		set.add("Gopi");
		
		//Collection<String> set = new TreeSet<>(Collections.reverseOrder());
		
		Iterator<String> it = set.iterator();
		String query = "Dhaval";
		boolean result = false;
		while (it.hasNext()) 
		{
			if (it.next().equals(query)) 
			{
				result = true;
				break;
			}
		}
		
		if (result) 
		{
			System.out.println(query + " exists");
		}
		else 
		{
			System.out.println(query + " doesn't exist");
		}	

	}

}