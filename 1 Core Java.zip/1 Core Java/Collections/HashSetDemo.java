import java.util.*;

public class HashSetDemo
{
 public static void main(String args[])
 {
  HashSet<String> h= new HashSet<String>();
  h.add("Ajay");
  h.add("Welcome");
  h.add("To");
  h.add("Yash Tech");
  
  Iterator<String> i= h.iterator();
  while(i.hasNext())
  {
   System.out.println(i.next());
  }
 for(String x: h)
 {
	System.out.println(x);
 }	 
 }
}
//will get set in random order because sets do not have indexing.
  