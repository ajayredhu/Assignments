import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapAssignment1
{

	public static void main(String[] args) {
		Map<Integer, String> map = new HashMap<>();
		
		map.put(10,"Ajay");
		map.put(20,"Dhaval");
		map.put(30,"Alok");
		
		
		Set<Entry<Integer, String>> set = map.entrySet();
		Iterator<Entry<Integer, String>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<Integer, String> me = it.next();
			
			if (me.getKey().equals("10")) {
				System.out.println("Key 10 exists");
				break;
			}
		}
		
	
		set = map.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) 
		{
			Map.Entry<Integer, String> me = it.next();
			
			if (me.getValue().equals("Ajay")) {
				System.out.println("Value Ajay exists");
				break;
			}
		}
		
		
		set = map.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<Integer, String> me = it.next();
			//System.out.println(me);
			System.out.println("Key: " + me.getKey() + ", Value: " + me.getValue());
		}
	}

}