import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapAssignment3
{
 public static void main(String[] args) 
	{
		HashMap<String, Integer> ContactList = new HashMap<String, Integer>();
		ContactList.put("Ajay",982737372);
		ContactList.put("Alok",987654321);
		ContactList.put("ekansh",984357283);
		ContactList.put("Rakesh",982536378);
		
		if(ContactList.containsKey(987654321))
		{
		 System.out.println("Key 987654321 is present");
		}
		if (ContactList.containsValue("Ajay"))
		{
		  System.out.println("Value Ajay is present");
		}
		Set s= ContactList.entrySet();//converted into set for traversing
		Iterator i= s.iterator();
		while(i.hasNext())
		{
		 Map.Entry en= (Map.Entry)i.next();
		 
		 System.out.println("Value : "+en.getValue()+ "Key : "+en.getKey());
		}
		
	}
}