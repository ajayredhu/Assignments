import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.*;

public class MapDemo1
{
	static Map<Integer, String> map= new HashMap<Integer,String>();
	
	public static void sortbykey()
    {
        TreeMap<Integer, String> sorted = new TreeMap<>();
        sorted.putAll(map);
		for (Map.Entry<Integer, String> entry : sorted.entrySet())
            System.out.println("Key = " + entry.getKey() +", Value = " + entry.getValue());       
    }
	
 public static void main(String args[])
 {
 
  map.put(10,"Ajay");
  map.put(11,"yash");
  map.put(12,"tech");
  map.put(13,"jaynam");

  sortbykey();
 }
}
//Use Comparator
//by using collections.sort we can sort the values.