import java.util.Vector;
 
 class VectorListDemo
 {
	public static void main(String args[])
	 {
		Vector<String> v1= new Vector<String>();
		v1.add("Ajay");
		v1.add("Redhu");
		System.out.println(v1);
  
		for(String x : v1)
		{
		System.out.println(x);
		}
	  }
 }