class PatientConstructor
{
	String patientNme; double height; double weight;
	PatientConstructor(double h, double w)
	{
		this.height=h;
		this.weight=w;
	}
	public void CalculateBMI()
	{
		double BMI= weight/height*height;
		System.out.println(BMI);
	}
	public static void main(String [] args)
	{
		PatientConstructor pc=new PatientConstructor(3,4);
		pc.CalculateBMI();
	}
}
