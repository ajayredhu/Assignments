import java.io.*;

class AllCheckedException
{
  public static void main(String ars[])
  {
	try
	{
		FileInputStream f1= new FileInputStream("D:/yash/ashshhsh.txt");
		
		FileInputStream f2= new FileInputStream("D:/yash/yash.txt");
		Class c= Class.forName("Abc");
	    	
		
	}
  catch(FileNotFoundException fn)
  {
	  fn.printStackTrace();
  }
  catch(ClassNotFoundException cfe)
  {
	cfe.printStackTrace();
  }

 finally
 {
	 System.out.println("All Checked Exceptions Handled Successfully");
	 
 }
  
  }
}