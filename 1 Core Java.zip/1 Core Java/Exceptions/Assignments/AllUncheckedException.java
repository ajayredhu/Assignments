import java.io.*;

class AllUncheckedException
{
 public static void main(String args[])
 {
 try
 {
  int a=10;
  int b=0;
  int c=a/b;
  System.out.println(c);
  
  String str= null;
  System.out.println(str.length());
  
  int a1[]= new int[] {1,2,3,4,5};
	System.out.println(a1[13]);
	
	String str1= "hello we are here";
    System.out.println(str1.charAt(66));
	
	String s1= "B27";
	int z= Integer.parseInt(s1);
	
	Object o= new Object();
	str=(String)o;
  } 
 catch(ArithmeticException ae)
 {
	 ae.printStackTrace();
 }
 catch(NullPointerException ne)
 {
	ne.printStackTrace();
 }
 catch(ArrayIndexOutOfBoundsException aie)
 {
	 aie.printStackTrace();
 }
 catch(NumberFormatException nfe)
 {
	nfe.printStackTrace();
 }
  finally
  {
	System.out.println("All four exceptions are handled sucessfully");
  }
 
 }

}