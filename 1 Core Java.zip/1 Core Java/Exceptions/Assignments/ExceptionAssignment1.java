import java.util.Scanner;

class ExceptionAssignment1
{
 public static void main(String args[])
 {
  try
   { int n2;
    Scanner sc= new Scanner(System.in);
	System.out.println("Please Enter a integer");
	String str= sc.nextLine();
	int num = Integer.parseInt(str);
	
	n2= num*num;
    System.out.println("Square of the number "+num+" is "+n2);
	
   }
   catch(NumberFormatException e)
   {
     System.out.println("Entered format is not a valid format");
   } 
 }
 
}