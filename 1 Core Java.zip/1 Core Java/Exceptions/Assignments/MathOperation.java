class MathOperation
{

public static void main(String[] args)
{
int []a = new int[5];
int sum=0;

try
{
for(int i=0;i<a.length;i++)
 { a[i]=Integer.parseInt(args[i]);
   sum=sum+a[i];

  }
}
catch(Exception e)
{
System.out.println(e);
}

System.out.println("Sum is"+sum);
System.out.println("Average is"+sum/4);




}

}