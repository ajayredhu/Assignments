import java.util.Scanner;

class InvalidCountryException extends RuntimeException
{
InvalidCountryException(String s)
{
  super(s);
}

}


class UserRegistration
{

public static void main(String[] args)
{
	//registerUser(args[0],args[1]);
	Scanner s = new Scanner(System.in);
	System.out.println("Enter username");
	String username=s.next();
	System.out.println("Enter Country");
	String country=s.next();
    registerUser(username,country);
	System.out.println("after method");
	
	
	
}


public static void registerUser(String username,String usercountry)
	{  try{
		if(usercountry.equals("India"))
			System.out.println("User Registration Successfully");
		else 
			throw new InvalidCountryException("User Outside India can not be resgistered");
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
		
	}
		
		
		
	}
	



}