import java.io.FileInputStream;
class Exception2
{
 public static void main(String args[])
 {
  try
   {
    String s= null;
    System.out.println(s.length());//Null pointer Exception 
   }
  catch(Exception e)
   {
    System.out.println(e);
   }
  System.out.println("Proper Termination");
 }
}