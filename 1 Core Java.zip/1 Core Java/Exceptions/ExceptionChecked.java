import java.io.FileInputStream;
class ExceptionChecked
{
 public static void main(String args[])
 {
  try
  {
   //FileInputStream f= new FileInputStream("D:/xyz.txt");//file not found exception at runtime(unchecked)
   Class.forName("com.mysql.jdbc.driver");//class not found exception at runtime(unchecked)
   
  }
  catch(Exception e)
  {
    System.out.println(e);
  }
 }
}