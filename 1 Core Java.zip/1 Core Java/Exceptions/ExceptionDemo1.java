class ExceptionDemo1
{
  public static void main(String args[])
  {
   System.out.println("Yash");
   System.out.println("Technologies");
   System.out.println("Ajay");
   System.out.println(100/0); //Runtime error:  java.lang.ArithmeticException: / by zero
   System.out.println("Bye"); //Bye was not printed.
  
  }
  
}