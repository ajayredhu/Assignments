class ExceptionFinally
{
 public static void main(String args[])
 {
  try
   {int c;
    int a=100, b=0;
	c = a/b;
    System.out.println(c);//Null pointer Exception 
	//System.exit();//Diresct exit no finally will be executed.
   }
   finally
   {
     System.out.println("I am in Finally Block");
   } 
 }
 
}