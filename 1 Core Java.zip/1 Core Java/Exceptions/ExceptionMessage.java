
class ExceptionMessage
{
 public static void main(String args[])
 {
  try
   { int c;
    int a=100, b= 0;
	c = a/b;
    System.out.println(c);//Null pointer Exception 
   }
  catch(Exception e)
   {
	e.printStackTrace();
    System.out.println(e);
	System.out.println(e.getMessage());
   }
  System.out.println("Proper Termination");
 }
}