import java.io.FileInputStream;

class ThrowsD2
{
  void show() throws NullPointerException
  {
   int a=1000; int b=0;
   int c= a/b;
   System.out.println(c);
  }
}
class ThrowsDemo2
{
 public static void main(String args[])
 {
 ThrowsD2 t2= new ThrowsD2();
 try
 {
 t2.show();
 }
 catch(NullPointerException e)
{
e.printStackTrace();
} 
  System.out.println("HELLO NORMAL TERMINATION");
 }
}