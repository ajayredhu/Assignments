import java.io.*;  
public class Assignment1
{
 public static void main(String args[]) 
 {
	int lines = 0;

    try (InputStream is = new BufferedInputStream(new FileInputStream("D:/yash/yash.txt"))) 
	  {
          byte[] c = new byte[200];
          int count = 0;
          int readChars = 0;
          boolean endsWithoutNewLine = false;
          while ((readChars =is.read(c))!=-1) 
		  {
            for(int i=0;i<readChars;++i) 
			{
                if (c[i] == '\n')
                      ++count;
            }
            endsWithoutNewLine = (c[readChars - 1] != '\n');
          }
          
		  if (endsWithoutNewLine) 
		  {
            ++count;
          }
          
		  lines = count;
      } 
	  catch (IOException e) 
	  {
        e.printStackTrace();
      }

    System.out.println("done");
  }
}