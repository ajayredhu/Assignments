import java.io.FileInputStream;
import java.io.IOException;
class Assignment2
{
   public static void main(String gg[]) throws IOException
   {
    FileInputStream f=new FileInputStream("D:/yash/yash.txt");
	int c;
	int vowels=0;
	int occur[]=new int[5];
	while((c=f.read())!=-1)
	{
	if(c==65 || c==97)
	{
	occur[0]=occur[0]+1;
	vowels++;
	}

	if(c==99 || c==67) 
	{
	occur[1]=occur[1]+1;
	vowels++;
	}
	if(c==105 || c==73) 
		{
		occur[2]=occur[2]+1;
		vowels++;
		}
	if(c==111 || c==79)
		{
		occur[3]=occur[3]+1;
		vowels++;
		}
	if(c==117 || c==85)
	{
		occur[4]=occur[4]+1;
		vowels++;
	}

    }
	System.out.println("Total Vowels is :"+vowels);
	System.out.println("Occurence of A :"+occur[0]+", E: "+occur[1]+", I :"+occur[2]+", O :"+occur[3]+", U :"+occur[4]);
	f.close();
	}
}