import java.io.*;

class CombinedDemo
{
public static void main(String args[])
 {
 try
 {
  FileInputStream f1= new FileInputStream("D:/yash/abc.txt");
  FileInputStream f2= new FileInputStream("D:/yash/xyz.txt");
  
  FileOutputStream fout= new FileOutputStream("D:/yash/Combined.txt");
  
  SequenceInputStream binput= new SequenceInputStream(f1,f2);
  int i;
  while((i=binput.read())!=-1)
  {
   System.out.print((char) i);
  }
  binput.close();
  f1.close();
  f2.close();
 } 
  catch(Exception e)
  {
   e.printStackTrace();
  }
  
 }
}