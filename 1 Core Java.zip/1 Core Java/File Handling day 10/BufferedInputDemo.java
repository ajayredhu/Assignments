import java.io.FileInputStream;
import java.io.BufferedInputStream;

class BufferedInputDemo
{
public static void main(String args[])
 {
 try
 {
  FileInputStream finput= new FileInputStream("D:/yash/xyz.txt");
  BufferedInputStream binput= new BufferedInputStream(finput);
  int i;
  while((i=binput.read())!=-1)
  {
   System.out.print((char) i);
  }
  binput.close();
  finput.close();
 } 
  catch(Exception e)
  {
   e.printStackTrace();
  }
  
 }
}