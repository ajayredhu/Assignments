import java.io.*;  
public class ByteArrayInputDemo
{  
  public static void main(String[] args) throws IOException {  
    byte[] brr = new byte[] {10,20,30,40};  
      
    ByteArrayInputStream b = new ByteArrayInputStream(brr);  
    int i= 0;  
    
	while ((i =b.read())!=-1) 
	{    
       
      System.out.println((char) i);  
    }  
  }  
}  