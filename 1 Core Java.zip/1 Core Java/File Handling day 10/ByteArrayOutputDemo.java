import java.io.*;  
public class ByteArrayOutputDemo 
{  
	public static void main(String args[]) throws Exception
	{    
      FileOutputStream fout1=new FileOutputStream("D:/yash/abc.txt");    
      FileOutputStream fout2=new FileOutputStream("D:/yash/xyz.txt");    
        
      ByteArrayOutputStream bout=new ByteArrayOutputStream();    
      bout.write("This is Yash Technologies Training");    
      bout.writeTo(fout1);    
      bout.writeTo(fout2);    
        
      bout.close();   
	  fout1.close();
	  fout2.close();
      System.out.println("Successfully Printed in both files");    
     }    
    }   