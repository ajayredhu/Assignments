import java.io.File;
import java.io.IOException;

class FileDemo2
{
	public static void main(String args[]) throws IOException
 {
  File f= new File("D:/yash/abc.txt");
  f.createNewFile();
  System.out.println(f.exists());
 }
}