import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

class FileInputOutputStreamDemo
{
	public static void main(String args[]) throws IOException
 {
  FileInputStream in= new FileInputStream("D:/yash/abc.txt");
  FileOutputStream out = new FileOutputStream("D:/yash/xyz.txt");
  
  int c;
  while((c=in.read())!=-1)
  {  out.write(c);
    //System.out.println(c);//prints ascii values
	System.out.print((char)c);//prints data inside
  }
    
	in.close();
	out.close();	 
 
 }
}