import java.io.*;

class Employee implements Serializable
{
 private String name;
 private String department;
 private String designation;
 private double salary;
  Employee()
  {
   System.out.println("This is no argument constructor");
  }
  
  Employee(String name, String department, String designation, double salary)
  {
    this.name= name;
	this.department= department;
	this.designation= designation;
	this.salary=salary;
  }
   
   public String toString()
   {
    return name+ "  " +department+ " " +designation +" "+salary;
   }
}

class EmployeeDemo
{
  public static void main(String args[]) throws Exception
  {
    Employee e= new Employee("ajay","IT","Software Dev",500000);
	
	File f= new File("D:/yash/abc.ser");
	ObjectOutputStream oos= new ObjectOutputStream(new FileOutputStream(f));
	oos.writeObject(e);
	oos.close();
  }
}