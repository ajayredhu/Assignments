import java.io.*;

class Employee implements Serializable
{
 private String name;
 private String department;
 private String designation;
 private double salary;
 
   public void setEmpName(String name)
   {
    this.name=name;
   }
   public String getEmpName()
   {
   return name;
   }
   
   public void setEmpDepatment(String department)
   {
    this.department=department;
   }
   public String getEmpDepartment()
   {
   return department;
   }
   
    public void setEmpDesignation(String designation)
	{
	 this.designation=designation;
	}
	public String getEmpDesignation()
   {
   return department;
   }
   
	public void setEmpSalary( double salary)
	{
	this.salary=salary;
	}
	public double getEmpSalary()
	{
	return salary;
	}
}

class EmployeeDemo2
{
  public static void main(String args[]) throws Exception
  {
    Employee e= new Employee();
	e.setEmpName("Ajay");
	//e.getEmpName();
	
	e.setEmpDepatment("IT");
	//e.getEmpDepartment();
	
	e.setEmpDesignation("SoftwareDev");
	//e.getEmpDesignation();
	
	e.setEmpSalary(500000);
	//e.geEmpSalary();//no need to get the values as these values are already set in the object
	
	File f= new File("D:/yash/yash.ser");
	ObjectOutputStream oos= new ObjectOutputStream(new FileOutputStream(f));
	oos.writeObject(e);
	oos.close();
	
	ObjectInputStream ois= new ObjectInputStream(new FileInputStream(f));
	e= (Employee)ois.readObject();
	ois.close();
    System.out.println(e);	
  }
}