public class enumWeekdaysSwitchDemo
{
 enum WeekdaysSwitch
 {SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY;}
  public static void main(String args[])
  {
   
	for(WeekdaysSwitch today: Weekdays)
{
  
  switch(today)
  {
   case SUNDAY :
   System.out.println("Today is : "+WeekdaysSwitch.valueOf("SUNDAY"));
   break;
   
   case MONDAY:
   System.out.println("Today is : "+WeekdaysSwitch.valueOf("MONDAY"));
   break;
   
   case TUESDAY:
   System.out.println("Today is : "+WeekdaysSwitch.valueOf("TUESDAY"));
   break;
   
   case WEDNESDAY:
   System.out.println("Today is : "+WeekdaysSwitch.valueOf("WEDNESDAY"));
   break;
  
   case THURSDAY:
   System.out.println("Today is : "+WeekdaysSwitch.valueOf("THURSDAY"));
   break;
   
   case FRIDAY:
   System.out.println("Today is : "+WeekdaysSwitch.valueOf("FRIDAY"));
   break;
   
   case SATURDAY:
   System.out.println("Value of "+WeekdaysSwitch.valueOf("SATURDAY"));
   break;
   default:
   System.out.println("Invalid");
  } 
  
  }
  
  }
 

}