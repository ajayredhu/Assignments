static class OuterDemo2
{
 class Inner
 {
  void show()
  {
  System.out.println("Inner class");
  }
 }
 public static void main(String args[])
 {
  OuterDemo2.Inner obj= new OuterDemo2.Inner();
  obj.show();
 } 
}

// modifier static not allowed here
//static class OuterDemo2
  //     ^