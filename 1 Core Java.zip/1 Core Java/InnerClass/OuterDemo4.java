class OuterDemo4
{
 void display()
 {
 System.out.println("Outer class display");
 }
 static class Inner
 {
  void show()
  {
  System.out.println("Inner class show");
  }
 }
 public static void main(String args[])
 {
  OuterDemo4.Inner obj= new OuterDemo4.Inner();
  obj.show();
  OuterDemo4 ob= new OuterDemo4();
  ob.display();
 } 
}

// output inner class show
// outer class display
