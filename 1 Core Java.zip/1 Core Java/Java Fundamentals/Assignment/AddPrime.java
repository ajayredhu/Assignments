class AddPrime{
	public static void main(String args[])
	{
		int a=Integer.parseInt(args[0]);
		int i, num=1 , count, sum=0;
		while(num<=a)
		{
			count=0;
			i=2;
			while(i<=num/2)
			{
				if(num%i==0)
				{
					count++;
					break;
				}
				i++;
			}
			if(count==0&&num!=1)
			{
				sum=sum+num;//summation
			}
			num++;
		}
		System.out.println(sum);
	}
}
