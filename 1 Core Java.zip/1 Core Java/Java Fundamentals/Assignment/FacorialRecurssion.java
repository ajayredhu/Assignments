class FactorialRecurssion{
	public static void main(String args[])
	{
		static int factorial(int n){
			if(n==0)
	}