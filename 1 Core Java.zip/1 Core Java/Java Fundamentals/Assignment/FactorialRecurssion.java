class FactorialRecurssion
{
	static int fact=1;
	public static void main(String args[])
	{
		int n=4;
		FactorialRecurssion obj=new FactorialRecurssion();
		obj.calcFact(n);
		System.out.println(fact);
	}
	void calcFact(int n)
	{
		if(n>=1)
		{
			fact=fact*n;
			calcFact(n-1);
		}
	}
}
		