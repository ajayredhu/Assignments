class Fibonacci{
	public static void main(String args[])
	{
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[1]);
		int count=Integer.parseInt(args[2]);
		int nextnum,i;
		System.out.println(num1+""+num2);
		for(i=2;i<count;i++){
			
			nextnum=num1+num2;
			System.out.println(""+nextnum);
			num1=num2;
			num2=nextnum;
		}
	}
}
