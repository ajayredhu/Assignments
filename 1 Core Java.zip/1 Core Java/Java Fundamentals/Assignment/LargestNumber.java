class LargestNumber
{
	public static void main(String args[])
	{
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int c=Integer.parseInt(args[2]);
		if(a>=b && a>=c)
		{
			System.out.println("first number is greater");
		}
		else if(b>=a && b>=c)
		{
			System.out.println("second number is grater");
		}
		else
		{
			System.out.println("third number is greater");
		}
	}
}
