import java.util.Scanner;
class StringPalindromeCheck
{
	public static void main(String[] args);
	{
		Scanner s=new Scanner(System.in);
		