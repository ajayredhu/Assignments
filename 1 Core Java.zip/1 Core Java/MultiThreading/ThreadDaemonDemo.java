public class ThreadDaemonDemo extends Thread
{
 public void run()
 {
  System.out.println("In Run Method");
  
  if(Thread.currentThread().isDaemon())
  {
   System.out.println("I am in Daemon Thread");
  }
  else
  {
   System.out.println("I am in non Daemon Thread");
  }
 }
 
 public static void main(String args[])
 {
	 System.out.println("Main Thread");
  ThreadDaemonDemo td = new ThreadDaemonDemo();
  td.setDaemon(true);
  td.start();
 }
}