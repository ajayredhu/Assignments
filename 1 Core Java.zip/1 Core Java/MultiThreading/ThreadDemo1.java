public class ThreadDemo1 extends Thread
{
 public void run()
 {
  System.our.println("Thread Started");
 }
 
 public static void main (String args[])
 {
  ThreadDemo t1= new ThreadDemo();
  t1.start();
 }
}