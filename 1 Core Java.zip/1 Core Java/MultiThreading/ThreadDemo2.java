public class ThreadDemo2 extends Thread
{
 public void run()
 {
  System.our.println("Thread Started");
 }
 
 public static void main (String args[])
 {
  ThreadDemo t1= new ThreadDemo();
  t1.start();
  ThreadDemo t2= new ThreadDemo()
  t2.start();
 }
}