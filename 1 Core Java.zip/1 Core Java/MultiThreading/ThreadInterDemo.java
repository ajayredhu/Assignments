public class ThreadInterDemo extends Thread
{
 public void run()
 {
  //System.out.println(Thread.interrupted());//true 1 2 3
  System.out.println(Thread.currentThread().isInterrupted());//true 1 sleep Interrupted
  try
  {
   for(int i=1;i<=3;i++)
   {
    System.out.println(i);
	Thread.sleep(1000);
	//System.out.println(Thread.interrupted());//1 Sleep Interrupted // when using both the interrupt: true 1 false 2 false 3 false 
	System.out.println(Thread.currentThread().isInterrupted());// both used Op= true 1 Sleep Interrupted
   }
  }
   catch(Exception e)
   {
    System.out.println(e);
   }
  
 
 }
 public static void main(String args[])
 {
  ThreadInterDemo tid= new ThreadInterDemo();
  tid.start();
  tid.interrupt();
 }
}