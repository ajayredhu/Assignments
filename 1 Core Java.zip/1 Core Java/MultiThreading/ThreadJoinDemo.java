
public class ThreadJoinDemo extends Thread
{
 public void run()
 {
  try
  {
   for(int i=0;i<=3;i++)
   {
    System.out.println("Run Thread"+i);
   }
  }
   catch(Exception e)
   {
    System.out.println(e);
   }
 }
 public static void main(String args[]) throws Exception
 {
  ThreadJoinDemo tj= new ThreadJoinDemo();
  tj.start();
  tj.join();
  
	try
	{
		for(int i=0;i<=3;i++)
		{
			System.out.println("Main Thread"+i);
			Thread.sleep(1000);
		}
	}
   catch(Exception e)
   {
    System.out.println(e);
   }
 }
}

/*
Run Thread0
Run Thread1
Run Thread2
Run Thread3
Main Thread0
Main Thread1
Main Thread2
Main Thread3

*/