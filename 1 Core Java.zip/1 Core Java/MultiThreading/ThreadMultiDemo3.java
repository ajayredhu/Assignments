class MyThreadDemo1 extends Thread
{
 public void run()
 {
  System.our.println("Thread Started");
 }
 

class MyThreadDemo2 extends Thread
{
 public void run()
 {
  System.our.println("Thread Started");
 }
 
 
class MyThreadDemo3 extends Thread
{
 public void run()
 {
  System.our.println("Thread Started");
 }
 
 
 
 public class ThreadDemoMulti3
 {
 public static void main (String args[])
 {
  MyThreadDemo1 t1= new MyThreadDemo1();
  t1.start();
  
  MyThreadDemo1 t1= new MyThreadDemo1();
  t2.start();
  
  MyThreadDemo1 t1= new MyThreadDemo1();
  t3.start();
 }
}