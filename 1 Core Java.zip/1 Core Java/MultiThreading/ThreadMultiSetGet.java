public class ThreadMultiSetGet extends Thread 
{
 public void run()
 {
  System.out.println("Run : "+Thread.currentThread().getName());
 }
 public static void main(String args[])
 {
  System.out.println(Thread.currentThread().getName());
  ThreadMultiSetGet tm= new ThreadMultiSetGet();
  tm.setName("Thread 1");
  tm.start();
  
  ThreadMultiSetGet td= new ThreadMultiSetGet();
  td.setName("Thread 2");
  td.start();
 }
}