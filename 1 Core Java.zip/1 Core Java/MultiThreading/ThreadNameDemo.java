public class ThreadNameDemo
{
 public static void main(String args[])
 {
  System.out.println(Thread.currentThread().getName());
  Thread.currentThread().setName("Ajay");
  System.out.println(Thread.currentThread().getName());
 }
}