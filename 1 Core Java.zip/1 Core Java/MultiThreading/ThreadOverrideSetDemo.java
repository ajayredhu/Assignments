public class ThreadOverrideSetDemo extends Thread
{
 public void run()
 {
  Thread.currentThread().setName("OverriddenThreadName")
  System.out.println(Thread.currentThread().getName());
 }
 public static void main(String args[])
 {
  ThreadOverrideSetDemo to= new ThreadOverrideSetDemo()
  to.setName("Ajay");
  to.start();
  
  ThreadOverrideSetDemo ts= new ThreadOverrideSetDemo()
  ts.setName("Rakesh");
  ts.start();
  
}