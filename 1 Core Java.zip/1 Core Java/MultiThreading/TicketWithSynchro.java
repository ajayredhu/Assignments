//Made the method as synchronized. in line number 7

class BookTicket
{
 int totalseats=12;
 
 synchronized void bookSeats(int seats)
 {
  if(totalseats>= seats)
  {
   System.out.println("Booked Successfully");
   totalseats= totalseats- seats;
   System.out.println("Remaining seats"+totalseats);
  }
  else
  {
   System.out.println("Seats are not avaialable : "+totalseats);
  }
  
 }
}

public class TicketWithSynchro extends Thread
{
 static BookTicket b;
 int seats;
 
 public void run()
 {
  b.bookSeats(seats);
 }
 
 public static void main(String args[])
 {
  b= new BookTicket();
  
  TicketWithSynchro p1= new TicketWithSynchro();
  p1.seats=8;
  p1.start();
  
  TicketWithSynchro p2= new TicketWithSynchro();
  p2.seats=10;
  p2.start();
  }
}