//Concept of block Synchronization using synchronized (this){}.
class BookTicket
{
 int totalseats=12;
 
 void bookSeats(int seats)
 {
  synchronized(this)
  {
    if(totalseats>= seats)
  {
   System.out.println("Booked Successfully");
   totalseats= totalseats - seats;
   System.out.println("Remaining seats : " +totalseats);
  }
  else
  {
   System.out.println("Seats are not avaialable : "+totalseats);
  }
  
  }
 }
}

public class TicketWithSynchro2 extends Thread
{
 static BookTicket b;
 int seats;
 
 public void run()
 {
  b.bookSeats(seats);
 }
 
 public static void main(String args[]) throws Exception
 {
  b= new BookTicket();
  
  TicketWithSynchro2 p1= new TicketWithSynchro2();
  p1.seats=8;
  p1.start();
  
  TicketWithSynchro2 p2= new TicketWithSynchro2();
  p2.seats=10;
  p2.start();
  }
}