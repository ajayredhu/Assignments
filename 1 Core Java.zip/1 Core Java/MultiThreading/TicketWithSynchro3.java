//Making variable static in line 4 and using synchronized in line 6.
class BookTickets
{
 static int totalseats = 12;
 
 static synchronized void bookSeats(int seats)
 {
  if(totalseats>= seats)
  {
   System.out.println("Booked Successfully");
   totalseats= totalseats- seats;
   System.out.println("Remaining seats"+totalseats);
  }
  else
  {
   System.out.println("Seats are not avaialable : "+totalseats);
  }
 }
}


class Thread1 extends Thread
{
 static BookTickets b;
 int seats;
 Thread1 (BookTickets b, int seats)
 {
  this.b=b;
  this.seats= seats;
  }
  
  public void run()
  {
   b.bookSeats(seats);
  }
}

class Thread2 extends Thread
{
 static BookTickets b;
 int seats;
 Thread2(BookTickets b, int seats)
 {
  this.b=b;
  this.seats= seats;
  }
  
  public void run()
  {
   b.bookSeats(seats);
  }
}

public class TicketWithSynchro3 extends Thread
{
  public static void main(String args[])
  {
    BookTickets b= new BookTickets();
	
	Thread1 t1= new Thread1(b, 8);
	t1.start();
	
	Thread1 t2= new Thread1(b,3);
	t2.start();
	
	Thread2 t3= new Thread2(b, 4);
	t3.start();
	
	Thread2 t4= new Thread2(b, 4);
    t4.start();	
  }
}