abstract class Football
{
 abstract void size();
}

class Nike extends Football
{
void size()
{
 System.out.println("Our footballs have the best quality in Size 5");
}
}
class Adidas extends Football
{
void size()
{
 System.out.println("Our footballs have the best quality in Size 4");
}
 public static void main(String args [])
 {
  Nike obj= new Nike();
  obj.show();
  Adidas obj1=new Adidas();
  obj1.show();
 }
}