abstract class GeneralBank{
	abstract double getSIR();//saving interest rate
	abstract double getFIR();// fixed interest rate
}
class ICICIBank extends GeneralBank
{
	double getSIR()//overiding
	{
		return 4;
	}
	double getFIR()//overiding
	{
		return 8.5;
	}
}
class SBIBank extends GeneralBank
{
	double getSIR()//overiding
	{
		return 4;
	}
	double getFIR()//overiding
	{
		return 7;
	}
}
class GeneralBankAssignment1
{
	public static void main(String args[])
	{
		ICICIBank i=new ICICIBank();
		SBIBank s=new SBIBank();
		System.out.println("for ICICIBank fixedintrestrate= "+ i.getFIR());
		System.out.println("for ICICIBank savinginterestrate= "+ i.getSIR());
		System.out.println("for SBIBank fixedinterestrate= "+ s.getFIR());
		System.out.println("for SBIBank fixedinterestrate= "+ s.getSIR());
		GeneralBank g=new SBIBank();
		System.out.println("general SBIBank fixedintrestrate= "+ g.getFIR());
		System.out.println("general SBIBank savingintrestrate= "+ g.getSIR());
	}
}
