class Fruit
{    
  private char name,taste;
	public void eat();
}

class Apple extends Fruit
{@Override
  public void eat()
  {
    System.out.println( " Name of the fruit is Apple");
	System.out.println( " Taste of the fruit is sweet");
  }  
}

class Orange extends Fruit
  {@Override
   public void eat() 
    {	
	 System.out.println("Name of the fruit is Orange");
	 System.out.println("Taste of the fruit is sour");
    }
}

class OverridringExample
{
  public static void main(string args[] )
   {
	Apple A = new Apple();
	A.eat();
	Orange O=new Orange();
	O.eat();
   }
}