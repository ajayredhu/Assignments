abstract class GeneralBank
{
  abstract double getSavingInterestRate();
  abstract double getFixedDepositeInterestRate();
}

class ICICIBank extends GeneralBank
{

 double getSavingInterestRate()
 {
  return 4;
 }
 
 double getFixedDepositeInterestRate()
 {
  return 8.5;
 }
 
}

class SBIBank extends GeneralBank
{
 double getSavingInterestRate()
  {
   return 4;
  }
  
 double getFixedDepositeInterestRate()
 {
  return 7;
 }
}
public class TestBank
{
	public static void main(String args[])
	{
	ICICIBank o = new ICICIBank();
	SBIBank b = new SBIBank();
	System.out.println("Saving Interest Rate of ICICI BANK is: " +o.getSavingInterestRate());
	System.out.println("Saving Interest Rate of ICICI BANK is: " +o.getFixedDepositeInterestRate());
	System.out.println("Saving Interest Rate of SBI BANK is: " +b.getSavingInterestRate());
	System.out.println("Saving Interest Rate of SBI BANK is: " +b.getFixedDepositeInterestRate());
	}
}