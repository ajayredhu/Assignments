interface A
  {
	void show();
  }
interface B
  {
	void display();
  }  
class MultiDemo implements A,B
{ 
 public void show()
 {
   System.out.println("In show method");
 }
  public void display()
 {
   System.out.println("In display method");
 }
  public static void main(String args[])
  {
  MultiDemo md= new MultiDemo();
  md.show();
  md.display();
  }
}