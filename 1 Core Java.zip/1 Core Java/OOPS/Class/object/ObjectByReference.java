class ObjectByReference
{
	String color;
	int age;
	public static void main(String args[])
	{
		ObjectByReference obj=new ObjectByReference();
		obj.color="black";
		obj.age=11;
		System.out.println(sheru.color+ "" + sheru.age);
	}
}
