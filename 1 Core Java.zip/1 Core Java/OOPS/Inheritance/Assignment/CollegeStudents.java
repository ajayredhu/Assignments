public class Person
{
	private String name;
	private int DOB;

	public Person(String n, int DOB)
	{
	  this.name = n;
	  this.DOB = DOB;
	}

	public String toString()
	{
	  return "Person[name="+name+",DOB="+DOB+"]";
	}
}

public class Teacher extends Person
{
	private double salary;

	public Teacher(String n, int DOB, double s)
    {
      super(n, DOB);
      thi.salary = s;
    }

    public String toString()
    {
      return "Teacher[super="+super.toString()+",salary="+salary+"]";
    }
}

public class Student extends Person
{
  private String StudentId;

  public Student(String n, int DOB, String StudentId)
  {
     super(n, DOB);
     this.StudentId = StudentId;
  }

  public String toString()
  {
    return "Student[super=" + super.toString() + ",StudentId=" + StudentId + "]";
  }
}


public class CollegeStudents extends Student
{
  public static void main(String[] args)
  {
    Person a = new Person("Ajay", 1998);
    Student b = new Student("Rakesh", 1994, "Java");
    Teacher c = new Teacher("jaynam", 1988, 65000);
    System.out.println(a);
    System.out.println(b);
    System.out.println(c);
  }
}