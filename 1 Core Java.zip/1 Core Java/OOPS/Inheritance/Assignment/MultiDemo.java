interface Father
{
 void Height();
}
interface Mother
{
 void Color();
}

class Son implements Father,Mother
{
	public void Height()
	{
		System.out.println("Height is taken from Father");
	}
	public void Color()
	{
		System.out.println("Color is taken from Mother");
	}
	
 public static void main(String args[])
 {
   Son s= new Son();
   s.Height();
   s.Color();
 }
}