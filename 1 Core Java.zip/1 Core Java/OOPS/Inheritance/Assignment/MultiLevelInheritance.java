class A
{
	void run()
	{
		System.out.println("class A is running");
	}
}
class B extends A
{
	void eat()
	{
		System.out.println("class B is eating");
	}
}
class MultiLevelInheritance extends B
{
	void talk()
	{
		System.out.println("class C is talking");
	}
	public static void main(String [] args)
	{
		MultiLevelInheritance obj1= new MultiLevelInheritance();
		obj1.talk();
		obj1.run();
		obj1.eat();
	}
}
