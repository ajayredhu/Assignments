class A
{
	void running()
	{
		System.out.println("HELLO I AM RUNNING");
	}
	void eating()
	{
		System.out.println("HELLO I AM EATING");
	}
}

class SingleInheritance extends A
{
	void display()
	{
		System.out.println("Main class Display");
	}
	
	public static void main(String [] args)
	{
		SingleInheritance obj1=new SingleInheritance();
		obj1.running();
		//obj1.eating();
		obj1.display();
	}
}

		