abstract class Vehicle
{
 abstract void show();
}
 class Car extends Vehicle
 {
  void show()
  {
  System.out.println("The car starts with the button or the key");
  }
 }
 
class Bike extends Vehicle
 {
  void show()
  {
  System.out.println("The Bike starts with the kick");
  }
  public static void main(String args[])
  {
   //Vehicle v= new Vehicle();
   Car c=new Car();
   c.show();
   
   Bike b= new Bike();
   b.show();
   
   
  }
  
 }