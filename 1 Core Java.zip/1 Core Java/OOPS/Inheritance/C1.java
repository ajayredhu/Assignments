class A1
{
	 void displayA()
     {
	  System.out.println("Class A");
     }
}
 
class B1 extends A1

 { 
  void displayB()
   {
    System.out.println("Clas B");
   }
 }
 class C1 extends B1
 {void displayC()
   {
    System.out.println("Clas C");
   }
	 public static void main(String args[])
  {
	A1 obj1= new A1();
	obj1.displayA();
	
	B1 obj2= new B1();
	obj2.displayA();
	obj2.displayB();
	
	C1 obj3= new C1();
	obj3.displayA();
	obj3.displayC();
	obj3.displayB();

  }
}