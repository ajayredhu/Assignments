class A2
 {void displayA()
 {
 System.out.println("Class A2");
 }
}
 
class B2 extends A2

 { 
  void displayB()
   {
    System.out.println("Clas B2");
   }
 }
 class C2 extends A2
 {
	 void displayC()
   {
    System.out.println("Clas C2");
   }
 public static void main(String args[])
  {
	A2 obj1= new A2();
	obj1.displayA();
	
	B2 obj2= new B2();
	obj2.displayA();
	obj2.displayB();
	
	C2 obj3= new C2();
	obj3.displayA();
	obj3.displayC();


  }
}