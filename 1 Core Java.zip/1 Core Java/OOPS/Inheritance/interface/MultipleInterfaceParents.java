interface Mother
{
	void cooking();
}
class Me
{
	void show()
	{
		System.out.println("this is Me");
	}
}
interface Father extends Me
{
	void job();
}
class MultipleInterfaceParents implements Mother,Father
{
	public void cooking()
	{
		System.out.println("My mother is making food for me");
	}
	public void job()
	{
		System.out.println("My father is a govt officer");
	}
	public static void main(String args[])
	{
		Parents p=new Parents();
		p.cooking();
		p.job();
	}
}