class Shape
{
	void draw()
	{
		System.out.println("Shape class method");
	}
	void erase()
	{
		System.out.println("Shape class Erasing method");
	}
}

class Circle extends Shape
{
	void draw()
	{
		System.out.println("override shape class draw method and now this is circle class method ");
	}
	void erase()
	{
		System.out.println("override shape class erase method and not this is circle class method");
	}
}
class Triangle extends Shape
{
	void draw()
	{
		System.out.println("override shape class method and now it is Triangle class method");
	}
	void erase()
	{
		System.out.println("override shape class erase method and now it is Triangle class method");
	}
}
class Square extends Shape
{
	void draw()
	{
		System.out.println("override shape class method and now it is Square class method");
	}
	void erase()
	{
		System.out.println("override shape class method and now it is Square class method");
	}
}

class shapeOverride
{
	public static void main(String[] args)
	{
		Shape obj1 = new Circle();
		Shape obj2 = new Triangle();
		Shape obj3 = new Square();
		obj1.draw();
		obj1.erase();
		obj2.draw();
		obj2.erase();
		obj3.draw();
		obj3.erase();
	}
}