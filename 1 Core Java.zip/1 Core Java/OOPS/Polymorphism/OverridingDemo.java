class Over
{
 public void display(int a)
 {
  System.out.println("This is Orignal method");
 }
}
class OverridingDemo extends Over
{
 @Override()
 public void display(String a)
 {
 System.out.println("This is overridden method");
 }
 public static void main(String args[])
 {
  OverridingDemo d= new OverridingDemo();
  d.display("ajay");
 }
}