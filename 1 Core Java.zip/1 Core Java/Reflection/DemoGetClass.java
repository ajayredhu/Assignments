class A{}

class DemoGetClass
{
 public static void main(String args[])
 {
  DemoGetClass d= new DemoGetClass();
  d.show(a);
 }
}