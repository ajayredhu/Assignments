
public class IsArrayDemo
{
  public static void main(String args[]) 
  {
    Class<int[]> c = int[].class;
    System.out.println(c.isArray());
  }
}
