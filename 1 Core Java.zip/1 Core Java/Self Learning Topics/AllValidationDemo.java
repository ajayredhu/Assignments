import java.util.regex.*;  
public class AllValidationDemo  
{  
public static boolean isValidMobileNo(String str1)  
{  
 Pattern ptrn = Pattern.compile("[0-9]{10}");  
 Matcher match = ptrn.matcher(str1);  
 return (match.find() && match.group().equals(str1));  
}  
public static boolean isValidEmail(String str2)
{
 Pattern ptrn1 = Pattern.compile("^(.+)@(.+)$");  
 Matcher match = ptrn1.matcher(str2);  
 return (match.find() && match.group().equals(str2));
}
 public static boolean isValidUrl(String str3)
 {
	Pattern p= Pattern.compile("^https:");
    Matcher match= p.matcher(str3);
	return (match.find());
 }

 public static void main(String args[])  
	{       
	String str = "9131702374";    
		if (isValidMobileNo(str))  
			System.out.println("It is a valid mobile number.");   
		else  
				System.out.println("Entered mobile number is invalid.");  

	String str2= "ajayredhu47@gmail.com";
		if (isValidEmail(str2))  
			System.out.println("It is a valid email.");   
		else  
				System.out.println("Entered email is invalid.");
			
	String str3 = "https:aah.org";    
		if (isValidUrl(str3))  
			System.out.println("It is a valid url.");   
		else  
				System.out.println("Entered url is invalid."); 
    }  
}   