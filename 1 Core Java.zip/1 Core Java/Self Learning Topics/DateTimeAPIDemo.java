//this date time is immutable and these thing came in java 8. This is Thread Safe.Only getter methods are there no setter method.
//can also chck leap year as well using isLeapYear(). provides boolean true false.
import java.time.*;
import java.time.format.DateTimeFormatter;
  
public class DateTimeAPIDemo
{ 
 public static void LocalDateTimeApi()
 {
    LocalDate date = LocalDate.now();//current date
    System.out.println("the current date is "+date);
	
	//Adding 50 days in the current date
	LocalDate d= LocalDate.now().plusDays(50);
	System.out.println("the date after 50 days from today is "+d);
	
	LocalDate d2= LocalDate.now().minusDays(50);
	System.out.println("the date before 50 days from today is "+d2);
	
	LocalDate d3= LocalDate.now();//for leap year
	boolean isLeapYear = d3.isLeapYear();
	System.out.println(isLeapYear);
	
    LocalTime time = LocalTime.now();//current time
    System.out.println("the current time is "+time);
	
    LocalDateTime current = LocalDateTime.now();// will give us the current time and date
    System.out.println("current date and time : "+ current);
 
    DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"); // to print in a particular format
   
    String formatedDateTime = current.format(format); 
    
    System.out.println("in formatted manner "+formatedDateTime);
  
    Month month = current.getMonth();// printing months days and seconds
    int day = current.getDayOfMonth();
    int seconds = current.getSecond();
    System.out.println("Month : "+month+" day : "+day+" seconds : "+seconds);
  
    // printing some specified date
    LocalDate date2 = LocalDate.of(1998,9,17);
    System.out.println("My Birth date is : "+date2);
  
    // printing date with current time.
    LocalDateTime specificDate = current.withDayOfMonth(24).withYear(2016);
	System.out.println("specific date with "+ "current time : "+specificDate);
  }
 
 public static void main(String[] args)
    {
        LocalDateTimeApi();
    }
}