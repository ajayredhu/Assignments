import java.awt.event.*;  
import javax.swing.*;    
public class JavaSwingDemo 
{ 
  void TextAreaExample()
	{  
        JFrame f1= new JFrame();  
        JTextArea area=new JTextArea("Welcome to Swing");  
        area.setBounds(10,30, 200,200);  
        f1.add(area);  
        f1.setSize(300,300);  
        f1.setLayout(null);  
        f1.setVisible(true);  
     }   

 void TextFieldExample()
  {
	JFrame f=new JFrame("Button Example");  
    final JTextField tf=new JTextField();  
    tf.setBounds(50,50, 150,20);  
    JButton b=new JButton("Click Here");  
    b.setBounds(50,100,95,30);  
    b.addActionListener(new ActionListener()
	{  
		public void actionPerformed(ActionEvent e)
		{  
			tf.setText("Ajay Redhu has made this button.");  
		}  
    });  
    f.add(b);f.add(tf);  
    f.setSize(400,400);  
    f.setLayout(null);  
    f.setVisible(true);  
  } 

  void ButtonExample()
  {      
	JFrame f=new JFrame("Button");            
	JButton b=new JButton(new ImageIcon("D:\\icon.png"));    	
	b.setBounds(100,100,100, 40);    
	f.add(b);    
	f.setSize(300,400);    
	f.setLayout(null);    
	f.setVisible(true);    
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    
   }   

 public static void main(String[] args) 
 {  
     new TextAreaExample();
	 new TextFieldExample();
	 new ButtonExample();
 } 
}  