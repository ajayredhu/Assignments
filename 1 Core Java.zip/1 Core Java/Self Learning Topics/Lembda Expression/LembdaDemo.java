import java.util.*;  
interface A
{
	void show();
}

public class LembdaDemo
{ public static void main(String args[])

{
 A obj;
 obj = ()-> System.out.println("This is lembda example");//this is how lembda expression is used. implemented interface.
obj.show();
 
} 
}