
public class RegexStringNumbersDemo {

	public static void main(String[] args) {
		String str = "0956HARDIK0123456789G21";

		String digits = str.replaceAll("[^0-9]","");

		System.out.println(digits);
		

	}

}
