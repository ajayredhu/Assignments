import java.regex.*;

public class RegexStringSplitDemo {
    public static void main(String args[])
    {
        String str = "This is my task today";
        String[] arrOfStr = str.split("is", 2);
 
        for (String a : arrOfStr)
            System.out.println(a);
    }
}