import java.util.regex.*;
class RegexAssignment1 
{
 public static void main(String[]args)
 {
	 //extracting number from a string.
	 
   Pattern p = Pattern.compile("//d+"); //digit occur more than 1 time.
   Matcher m =  p.matcher("abcd1234efghi567jkl");
   while(m.find())
   {
    System.out.println(m.group());
   }
 }
}