import java.util.regex.*;
class RegexAssignment2
{
 public static void main(String[]args)
 {
	 // spliting the string into new line.
	 
	String s = "Ajay@redhu";
    String[] str = s.split("@" , 2);
	
	for (String a: str)
	{
		System.out.println(a);
	}
 }
}