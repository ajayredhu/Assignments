import java.util.regex.*;
class RegexAssignment3
{
  public static void main(String[]args)
  {
	  //extracting substring.
	  
	  Pattern p = Pattern.compile("\\b\\W+ @abc\\b");
	  Matcher m = p.matcher("k@abc\n" + "l@xyz\n" + "m@wxy\n");
	  
	  while(m.find())
	  {
		  System.out.println(m.group());
	  }
	  
	    
  }  
}