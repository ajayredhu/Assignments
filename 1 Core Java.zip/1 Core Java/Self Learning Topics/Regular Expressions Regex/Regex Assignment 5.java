import java.util.regex*;
Class RegexAssignment5
{
  public static void main(String[]args)
  {
	  //phone number validation
    Pattern p = Pattern.compile("^//d{10}$");
	Matcher m = p.matcher(9856545437);
	boolean b = m.matches();
	System.out.println(b);
	
	//email validation.
	pattern p1 = Pattern.compile("^[a-zA-Z0-9+._]+@[a-zA-Z0-9+._] + $");
	Matcher m1 = p1.matcher("abc12.@gmail.com");
	boolean b1 = m1.matches();
	System.out.println(b1);
	
	// url validation.
	pattern p2 = Pattern.compile("((http|https)//)(www.)?" + "^[a-zA-Z0-9+._]+@[a-zA-Z0-9+._] + $");
	Matcher m2 = p2.matcher("http://google.com");
	boolean b2 = m2.matches();
	System.out.println(b2);
	
	//date validation
  //Pattern p3 = Pattern.compile(^("\\d[0-2]|0[1-9]/(3[01]|[12][0-9]/[0-9]{4}$"));
  Pattern p3 = Pattern.compile(^("\\d{2}-\\d{2}-\\d{4}"));
	Matcher m3 = p3.matcher("03-04-2004"); //valid
	Matcher m4 = p3.matcher("3-04-2004");  //not valid
	boolean b3 = m3.matches();
	boolean b4 = m4.matches();
	System.out.println(b3);
	System.out.println(b4);
	
  }
}