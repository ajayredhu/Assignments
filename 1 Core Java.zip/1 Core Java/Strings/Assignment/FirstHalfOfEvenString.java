import java.util.Scanner;
class FirstHalfOfEvenString
{
 public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the string:");
	String s1=sc.nextLine();
	
	if(s1.length()%2==0)
		System.out.println(s1.substring(0,s1.length()/2));
	else
		System.out.println("Null");
}}