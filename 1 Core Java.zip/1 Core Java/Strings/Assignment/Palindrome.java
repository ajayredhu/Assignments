import java.util.Scanner;

class Palindrome
{
 public static void main(String args[])
{
 Scanner sc=new Scanner(System.in);
 System.out.println("Enter your name");
 String name = sc.nextLine() ;
 String reverse="";
 
 for(int i=name.length()-1; i>=0 ;i--)
  {
   reverse=reverse+name.charAt(i);
  }
  System.out.println("The reverse string is:" +reverse);

 if(name.equals(reverse))
  {
  System.out.println("It is a palindrome");
  }
  else
  {
  System.out.println("It is not a palindrome");
  }
 sc.close();
}}