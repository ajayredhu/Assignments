import java.util.Scanner; 
class SubString
{
 public static void main(String args[])
{
 Scanner sc=new Scanner(System.in);
 System.out.println("Enter the string:");
 String s1=sc.nextLine();
System.out.println(s1.substring(1,4));}}