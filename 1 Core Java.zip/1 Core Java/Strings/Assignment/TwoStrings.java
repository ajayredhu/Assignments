import java.util.Scanner;
class TwoStrings
{
 public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	String s1=sc.nextLine();
	String s2=sc.nextLine();
	int length1=s1.length();
	int length2=s2.length();
	int i=0;
	String s="";
	while(i<length1 && i<length2)
	{
		s= s+s1.charAt(i);
		s= s+s2.charAt(i);
		i++;
	}
	while(i<length1)
	{ 
	     s=s+s1.charAt(i);
		 i++;
	}
    while(i<length2)
	{ 
	     s=s+s2.charAt(i);
		 i++;
	}
	System.out.println(s);
}}

