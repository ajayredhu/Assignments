import java.io.BufferedReader;
import java.io.InputStreamReader;
class BufferReaderDemo
{
	public static void main(String [] args) throws Exception
	{
		InputStreamReader obj= new InputStreamReader(System.in);
		BufferedReader b= new BufferedReader(obj);
		System.out.println("your name");
		String name=b.readLine();
		System.out.println("your name="+ name);
	}
}