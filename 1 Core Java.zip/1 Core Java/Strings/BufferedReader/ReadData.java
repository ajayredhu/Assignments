import java.io.BufferedReader;
import java.io.InputStreamReader;

class Employee
{ String name;
  int age;
  void setEmployee(String name, int age)
  {
   this.name=name;
   this.age=age;
  }
  
  public void getEmployee()
  {
  System.out.println(name);
  System.out.println(age);
  }
}

public class ReadData
{
 public static void main(String args[]) throws Exception
 {
   InputStreamReader i= new InputStreamReader(System.in); 
   BufferedReader b= new BufferedReader(i);
   System.out.println("Enter your name");
   String name= b.readLine();
   
   System.out.println("Enter your age");
   int age=Integer.parseInt(b.readLine());

  Employee obj= new Employee();
  obj.setEmployee(name,age);
  obj.getEmployee();
 
 }
}