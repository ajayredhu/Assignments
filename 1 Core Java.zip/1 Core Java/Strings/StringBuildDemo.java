import java.util.*;
class StringBuildDemo
{ public static void main(String args[])
	{
		StringBuilder s=new StringBuilder("yash");
		System.out.println(s);
		s.append("Hello");
		System.out.println(s);
	}
}