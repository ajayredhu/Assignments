class Stringbufferdemo
{
 public static void main(String args[])
 {
    StringBuffer s1= new StringBuffer("Welcome to yash tech");
	  s1.replce(0,7,"Ajay")
	   System.out.println(s1);
 
 
 }




}