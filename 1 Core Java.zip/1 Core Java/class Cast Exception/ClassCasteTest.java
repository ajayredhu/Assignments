class ClassCasteTest
{
	public static void main(String args[])
	{
		Object o=new Object();
		String s=(Object)o;
		System.out.println(s);
	}
}