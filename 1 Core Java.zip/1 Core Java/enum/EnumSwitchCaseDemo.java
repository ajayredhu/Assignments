class EnumSwitchCaseDemo
{
	enum Day{
	MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;}
	public static void main(String args[])
	{
		//Day[] dweek=Day.values();
		//for(Day td:dweek)
		for(Day td:Day.values())// foreach loop
		{
			switch(td)
			{
				case MONDAY:
				System.out.println(td);
				break;
				case TUESDAY:
				System.out.println("tuesday there");
				break;
				case WEDNESDAY:
				System.out.println("wednesday there");
				break;
				case THURSDAY:
				System.out.println("thursday there");
				break;
				case FRIDAY:
				System.out.println("friday there");
				break;
				case SATURDAY:
				System.out.println("saturday there");
				break;
				case SUNDAY:
				System.out.println("today is holiday");
				break;
			}
			
		}
		System.out.println("value of tuesday: "+Day.valueOf("TUESDAY"));
		System.out.println("index of thursday: "+Day.valueOf("THURSDAY").ordinal());
	}
}