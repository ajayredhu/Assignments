class EnumSwitchCaseDemo2
{
	enum Seasons{
		WINTER,RAINY,SUMMER,SPRING;}
	public static void main(String args[])
	{
		for(Seasons s:Seasons.values())// foreach loop
		{
			switch(s)
			{
				case WINTER:
				System.out.println(s);
				break;
				case RAINY:
				System.out.println(s);
				break;
				case SUMMER:
				System.out.println(s);
				break;
				case SPRING:
				System.out.println(s);
				break;
				
			}
			
		}
		System.out.println("value of SPRING: "+Seasons.valueOf("SPRING"));
		System.out.println("index of SUMMER: "+Seasons.valueOf("SUMMER").ordinal());
	}
}