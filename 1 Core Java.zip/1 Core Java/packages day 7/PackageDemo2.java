import newpackage.MyProject;
class PackageDemo2
{
	public static void main(String args[])
	{
	MyProject mp= new MyProject();
	mp.display();
	}
}