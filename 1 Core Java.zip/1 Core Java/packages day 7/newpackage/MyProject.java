package newpackage;
public class MyProject
{
  public void display()
  {
   System.out.println("You are here in my project");
  }
}
