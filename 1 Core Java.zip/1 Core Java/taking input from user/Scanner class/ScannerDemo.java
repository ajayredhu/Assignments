import java.util.Scanner;
class ScannerDemo
{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.print("enter you name: ");
		String s=sc.nextLine();
		System.out.println("my name is="+s);
	}
}
		