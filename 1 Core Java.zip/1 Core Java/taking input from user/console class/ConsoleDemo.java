import java.io.Console;
class ConsoleDemo
{
	public static void main(String args[])
	{
		String str;
		char ch[];
		Console obj=System.console();
		System.out.println("enter the user name");
		str=obj.readLine();
		System.out.println("enter the Password");
		ch=obj.readPassword();
		String a=String.valueOf(ch);
		System.out.println("user name="+str+"   " +"password="+ch);
		System.out.println("main password="+a);
	}
}

