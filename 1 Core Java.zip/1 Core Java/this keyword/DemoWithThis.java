class Demo1
{
	int i; // Instance variable
	
	void setValue(int i)// local variable
	{
	this.i=i;
	}
	void show()
	{
		System.out.println(i);
	}
}
class DemoWithThis
{
	public static void main(String args[])
	{
	 Demo d= new Demo();
     d.setValue(15);
	 d.show();	 
	
	}
}
