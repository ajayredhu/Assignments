class Enmployee
{
	private int emp_id;//data hiding
	public void setEmp_id(int emp_id)
	{
		this.emp_id= emp_id;
	}
	public int getEmp_id()
	{
		return emp_id;
	}
}
class Organisation
{
	public static void main(String args[])
	{
	 Employee e= new Employee();
	 e.setEmp_id(1000);
	 System.out.println("e.getEmp_id");
	
	}
}
