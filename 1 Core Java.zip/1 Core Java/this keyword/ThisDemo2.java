class ThisDemo2
{
	void display()
	{
	 System.out.println("yash");
	}
	void show()
	 {
	 display();
	 //this.display();
	 }
	
	public static void main(String args[])
	{
	 ThisDemo2 t= new Demo();
	 t.show();	 
	
	}
}
