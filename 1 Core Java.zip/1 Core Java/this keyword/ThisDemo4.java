class ThisDemo4
{
	void y1()
	{
		System.out.println("Y1 Method");
		
	}
	void y2()
	{
		y1(this);
	}
	
	public static void main(String args[])
	{
	  ThisDemo4 obj= new ThisDemo4();
	  obj.y2();
	  
	}
}
