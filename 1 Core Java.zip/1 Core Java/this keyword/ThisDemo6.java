class Demo
{
	int age;
	String name;
 void show(int age, String name)
  {
	  this.age=age;
	  this.name= name;
  }
  void display()
  {
	  System.out.println(age+" "+name);
  }
	 
 }
 class ThisDemo6
 {
	public static void main(String args[])
	{
	  Demo obj= new Demo("Ajay",23);
      obj.display();
	  
	}
}
