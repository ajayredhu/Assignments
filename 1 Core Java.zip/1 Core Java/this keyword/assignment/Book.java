class Author
{
 private String name, String email, char gender;
  
  Author(String name, String email, char gender)
  {
   this.name=name;
   this.email=email;
   this.gender=gender;
  }
  public String getname()
  {retun name;}
  public String getemail()
  {return email;}
  public char getgender()
  {return gender;}
public String toString()
{
	return name=""+email+""+gender;
} 
}

class Book
{
	public void setprice(double)
	{this.price=price;}
   
   this.BookName=BookName;
   this.price=price;
   this.qtyinstock=qtyinstock;
    super.Author=Author;
   }
   public void getprice()
   {
    return BookName;
	return Author;
	return price;
	return qtyinstock;
   }
 
 
 public static void main(String args[])
 {
  Author details= new Author();
  details.setAuthor("ajay","ajayredhu@gmail.com",M);
  details.getAuthor();
  
  Book details1=new Book();
  details1.setBook("jack Sparrow the living legend",486,1000);
  details1.getbook();
  
  
  
 }
 
}