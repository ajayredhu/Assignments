class Box
{
	
double width();
double height();
double depth();


  Box(width,height,depth)
  {
	this.width=width;
	this.height=height;
	this.depth= depth;
  }
  
  double volume
  {
	  return width*height*depth;
  }
}
class DemoBox
{
	public static void main(String args[])
	{
		Box b= new Box(100,100,100);
		b.volume();
		System.out.println(volume);
	}
}