package com.automobile;

abstract public class Vehicle
{
abstract public String getModelName();
abstract public String getRegistrationNumber();
abstract public String getOwnerName();


}