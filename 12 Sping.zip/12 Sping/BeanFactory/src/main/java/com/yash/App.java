package com.yash;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//Implementing Injection using BeanFactory.xml
public class App{

  // Main driver method
  public static void main(String[] args) {

    // Creating object in a spring container (Beans)
    BeanFactory factory = new ClassPathXmlApplicationContext("com/yash/BeanFactory.xml");
    Employee employee = (Employee) factory.getBean("emp");

    System.out.println(employee);
  }
}