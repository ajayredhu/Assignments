package com.yash.BeanPostProcessor;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Message {
	
	private Integer messageId;
	private String message;
	
	public Message() {
		System.out.println("Message Object is created");
	}
	
	public Integer getMessageId() {
		return messageId;
	}
	public void setMessageId(Integer messageId) {
		System.out.println("setMessageId");
		this.messageId = messageId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		System.out.println("setMessage");
		this.message = message;
	}
	
	@PostConstruct
	public void init() throws Exception {
		System.out.println("message bean is ready to use..");
	}
	@PreDestroy
	public void destroy() throws Exception {
		System.out.println("message bean is going to destroy.");
	}
}
