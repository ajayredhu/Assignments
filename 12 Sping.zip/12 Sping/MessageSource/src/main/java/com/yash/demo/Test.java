package com.yash.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test
{
	public static void main(String args[])
	{
		
		ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		 
		System.out.println(context.getMessage("message",null,"Default Message",null));
		((AbstractApplicationContext) context).close();

	}

}
