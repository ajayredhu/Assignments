package com.automobile.twowheeler;
import com.automobile.Vehicle;

class Hero extends Vehicle
{

 public String getModelName()
 {
   return "HeroPassionPro";
 
 }
 public String getRegistrationNumber()
 {
    return "MP09VD1108";
 }
 
 public String getOwnerName()
 {
   return "Hardik Jain";
 }
 
 

public int getSpeed()
{
System.out.println("Speed is 40");
 return 34;
}

public void radio()
{
System.out.println("No option for radio");

}


}


class Honda extends Vehicle
{

public String getModelName()
 {
   return "HondaCBR";
 
 }
 public String getRegistrationNumber()
 {
    return "MP09SJ5912";
 }
 
 public String getOwnerName()
 {
   return "Ajay Redhu";
 }

public int getSpeed()
{
System.out.println("Speed is 40");
return 45;
}

public void cdplayer()
{
System.out.println("No option for cdplayer");

}
}

class TestMain
{


public static void main(String[] args)
{
 Hero he = new Hero();
 he.getSpeed();
 System.out.println(he.getOwnerName());

}

}