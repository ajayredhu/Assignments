package Collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
 public static void main(String args[])
 {
	 System.out.println("Spring Collections injection ");
	 ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
	 CollectionDemo cd= (CollectionDemo)context.getBean("CollectionDemo");
	 
	 cd.getAddresslist();
	 cd.getAddressSet();
	 cd.getAddressMap();
	 cd.getAddressProp();
	 
 }
}

