package Collection;
import java.util.*;

public class CollectionDemo {
	List addresslist;
	Set addressSet;
	Map addressMap;
	Properties addressProp;
	
	public void setAddresslist(List addresslist) {
		this.addresslist = addresslist;
	}
	public List getAddresslist() {
		System.out.println("Address List : "+addresslist);
		return addresslist;
	}
	
	
	public void setAddressSet(Set addressSet) {
		this.addressSet = addressSet;
	}
	public Set getAddressSet() {
		System.out.println("Address Set : "+addressSet);
		return addressSet;
	}
	
	
	public Map getAddressMap() {
		return addressMap;
	}
	public void setAddressMap(Map addressMap) {
		this.addressMap = addressMap;
	}
	
	
	public void setAddressProp(Properties addressProp) {
		this.addressProp = addressProp;
	}
	public Properties getAddressProp()
	{
		System.out.println("Property Elements : "+addressProp);
		return addressProp;
	}

}
