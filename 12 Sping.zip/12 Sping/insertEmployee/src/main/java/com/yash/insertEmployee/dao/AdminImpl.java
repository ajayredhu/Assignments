package com.yash.insertEmployee.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.yash.insertEmployee.entities.Admin;



public class AdminImpl implements AdminDao {
	private JdbcTemplate jdbctemp;


	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
		}
		public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
		}
		
	public int createAccount(Admin stu) {
		String q="insert into admin(emailid,pass_code) values(?,?)";
		int msg=this.jdbctemp.update(q,stu.getEmailid(),stu.getPass_code());
		return msg;
	}
	
	public Admin selectDetails(String aEmail,String aPass_code) {
		String q="select * from admin where emailid =? and pass_code=?";
		RowMapper<Admin> rowmapper=new AdminRowMapper();
		Admin admin=this.jdbctemp.queryForObject(q,rowmapper,aEmail,aPass_code);
		System.out.println(admin);
		

		return admin;
	}

	
}
