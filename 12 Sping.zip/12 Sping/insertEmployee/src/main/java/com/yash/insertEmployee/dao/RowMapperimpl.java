package com.yash.insertEmployee.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.insertEmployee.entities.Employee;



public class RowMapperimpl implements RowMapper<Employee>{
	
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Employee employee=new Employee();
		
		employee.setName(rs.getString(1));//column name-1
		employee.setEmailid(rs.getString(2));//column name-2
		employee.setDob(rs.getString(3));//column name-3
		employee.setContactno(rs.getDouble(4));//column name-4
		employee.setSalary(rs.getInt(5));//column name-5

		return employee;
		}



}
