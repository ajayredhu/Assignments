package com.yash.springAOP.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {

	@Before("execution(* com.yash.springAOP.services.PaymentServiceImpl.makePayment())")
	public void printBefore() {
		System.out.println("Payment Initilaized");
	}

	@After("execution(* com.yash.springAOP.services.PaymentServiceImpl.makePayment())")
	public void printAfter() {
		System.out.println("Payment Completed");
	}
	
	@Pointcut("execution(* com.yash.springAOP.services.PaymentServiceImpl.makePayment())")
	public void CustomMethod() {}
	
	//@Pointcut("execution(public void *.makePayment())")
	//public void myCustomMethod() {}
	
}