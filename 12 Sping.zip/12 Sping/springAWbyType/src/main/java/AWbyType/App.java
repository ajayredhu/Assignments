package AWbyType;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
 public static void main(String args[])
 {
	 System.out.println("Spring AutoWiring injection ");
	 ApplicationContext context=new ClassPathXmlApplicationContext("AWbyType/ApplicationContext.xml");
	 
	 Employee e=context.getBean("emp",Employee.class);
	 System.out.println(e);
 }
}

