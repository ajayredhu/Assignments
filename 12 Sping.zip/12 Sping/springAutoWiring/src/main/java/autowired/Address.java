package autowired;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
//using ApplicationContextAware and BeanNameAware Interfaces
public class Address implements ApplicationContextAware,BeanNameAware
{
private ApplicationContext appcon=null;
private String street;
private String city;

public String getStreet() {
return street;
}
public void setStreet(String street) {
this.street = street;
}
public String getCity() {
return city;
}
public void setCity(String city) {
this.city = city;
}


@Override
public String toString() {
return "Address [street=" + street + ", city=" + city + "]";
}
@Override
public void setApplicationContext(ApplicationContext context) throws BeansException 
{
 	this.appcon=context;
	
}
@Override
public void setBeanName(String name) {
	// Printing all the bean names
	System.out.println(name);
}

}