package springAutoWiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
 public static void main(String args[])
 {
	 System.out.println("Spring AutoWiring injection ");
	 ApplicationContext context=new ClassPathXmlApplicationContext("springAutoWiring/ApplicationContext.xml");
	 
	 A a=context.getBean("a",A.class);
	 a.display();
 }
}

