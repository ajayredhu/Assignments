package springAutoWiring;

public class B {
B()
{
 System.out.println("B class Constructor");	
}
void print()
{
	System.out.println("Hello B Class Here");
}
}
