package com.yash.springORM;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.yash.springORM.dao.StudentDao;
import com.yash.springORM.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		StudentDao studao = context.getBean("studentDao", StudentDao.class);
		Student s = new Student();
	
		
		System.out.println("Select Your Choice: 1 Insert 2 Update 3 Delete 4 Print");
		Scanner sc = new Scanner(System.in);
		int c=sc.nextInt();
		
		if(c==1)
		{
			
			
			System.out.println("Enter Unique id:");
			Scanner sc3=new Scanner(System.in);
			int id=sc3.nextInt();
			
			System.out.println("Enter Unique Name:");
			Scanner sc2=new Scanner(System.in);
			String name=sc2.next();
			
			
			s.setId(id);
			s.setName(name);
			
			int msg = studao.insert(s);
			System.out.println(msg + " insertion done");
			
		
			
		}
		else if(c==2)
		{   
			System.out.println("Enter Unique id you want to update: ");
			Scanner sc3=new Scanner(System.in);
			int id=sc3.nextInt();
			
			System.out.println("Enter new Name:");
			Scanner sc4=new Scanner(System.in);
			String stu=sc.next();
			
			s.setId(id);
			s.setName(stu);
			
			studao.updateDetails(s);
			System.out.println( " Updated Successfully ");
		}
		else if(c==3)
		{
			
			System.out.println("Enter id which is you want to delete");
			Scanner sc1=new Scanner(System.in);
			int stuid=sc1.nextInt();
			
			System.out.println("Enter new Name:");
			Scanner sc4=new Scanner(System.in);
			String name=sc.next();
			
			s.setId(stuid);
			s.setName(name);
			studao.deleteDetails(stuid);
			System.out.println("Deleted Successfully ");
			
		}
		else if(c==4)
		{
			System.out.println("Enter Unique Id");
			Scanner sc7=new Scanner(System.in);
	        int stuid=sc7.nextInt();
	        
	        Student s2=studao.getStudentDetails(stuid);
			System.out.println(s2);

		}
		else
		{
			System.out.println("Please Select right option");
		}
		}

	    
	
}