package com.yash.springmvcCrud;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DemoController 
{
	
	@RequestMapping("/ab")
	public String index()
	{
		return "index";
	}

}
