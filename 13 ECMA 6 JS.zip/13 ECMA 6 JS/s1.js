class s1
{
  static show()
   {
    console.log("this is static show");
   }
}
s1.show();