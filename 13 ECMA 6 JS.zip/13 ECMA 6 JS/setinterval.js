setInterval(fun1,1000);
setInterval(show,500);
function fun1()
{
  console.log("fun 1 is calling after every one second");
}
function show()
{
	console.log("function show is called every 500 ms ");	
}