//program having bufferreader input from console and also having update querry implementation.

import java.sql.*; 
import java.io.BufferedReader;
import java.io.InputStreamReader;
class ConsoleInputDemo
  {  
	public static void main(String args[])
	{  
		try{  
			Class.forName("com.mysql.jdbc.Driver"); 
			String url= "jdbc:mysql://localhost:3306/ajay";
			String user="root";
			String pass="root";
  
			Connection con=DriverManager.getConnection(url,user,pass);
			
			PreparedStatement stmt=con.prepareStatement("insert into employee values(?,?)");

			BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
			System.out.println("Please enter a id to insert into database.");
			int id= Integer.parseInt(br.readLine()); 
			System.out.println("Please enter a name to insert into database.");
			String name = br.readLine();
			
			stmt.setInt(1,id);//1 specifies the first parameter in the query  
			stmt.setString(2,name);  
  
			int i=stmt.executeUpdate();  
			System.out.println(i+" records inserted");
			
			String query= "update employee set EmpName= ? where EmpId= ?";
			PreparedStatement stmt1=con.prepareStatement(query);
			stmt1.setString(1,"Rahul");
			stmt1.setInt(2,104);

			i=stmt1.executeUpdate();  
			System.out.println(i+" records updated");  
  
  
			con.close();  
  
           }
		catch(Exception e)
		{ System.out.println(e);}  
    }
}
