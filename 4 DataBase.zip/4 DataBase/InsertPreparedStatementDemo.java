import java.sql.*;  
class InsertPreparedStatementDemo
  {  
	public static void main(String args[])
	{  
		try{  
			Class.forName("com.mysql.jdbc.Driver"); 
			String url= "jdbc:mysql://localhost:3306/ajay";
			String user="root";
			String pass="root";
  
			Connection con=DriverManager.getConnection(url,user,pass);  
  
			PreparedStatement stmt=con.prepareStatement("insert into employee(EmpId, EmpName) values(?,?)");  //in metods there is no d in prepareStatement.
			stmt.setInt(1,104);  
			stmt.setString(2,"Rakesh");  
  
			int i=stmt.executeUpdate();  
			System.out.println(i+" records inserted");  
  
			con.close();  
  
			}
		catch(Exception e)
		{ 
		System.out.println(e);
		}  
  
  }  
}  