import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
class InstertDemo
{
	public static void main(String args[])
	{
		try
		{
			//Step1: load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Step2: create connection
			String url="jdbc:mysql://localhost:3306/rajkuwar";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			
			//step3: creating query
			String q="insert into employee(empID,name) values(?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			
			//taking input from user
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("enter empid= ");  
			int empID=Integer.parseInt(br.readLine());  
			System.out.println("enter name= ");  
			String name=br.readLine(); 
			
			
			//setting the values
			ps.setInt(1,empID);//1 is coloumn no, if directly give the input-->(1,101);
			ps.setString(2,name);//2 is coloumn no, if directly give the input-->(2,"raj");
			ps.executeUpdate();
			System.out.println("inserted successfuly");
			
			
			//step 4: close connection
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}