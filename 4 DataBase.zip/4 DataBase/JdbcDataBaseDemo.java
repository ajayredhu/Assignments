import java.sql.*;
class JdbcDataBaseDemo
{
	public static void main(String args[])
	{
		try
		{
			//Step1: load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Step2: create connection
			String url="jdbc:mysql://localhost:3306/rajkuwar";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("connection done successfully");
			}
			else
			{
				System.out.println("connection not done");
			}
			
			//Step3: create query
			String q="select * from employee";
			//Statement st=con.createStatement();//statement
			PreparedStatement stmt=con.prepareStatement(q);//prepareStatement 
			  
			ResultSet set=stmt.executeQuery();
			//ResultSetMetaData rsmd=set.getMetaData();//ResultSetMetaData
			
			
			
			//Step4: process the data
			while(set.next())
			{
				int id=set.getInt("empID");//(1)col no
				String name=set.getString("name");
				System.out.println("id :" +id);
				System.out.println("name :" +name);
				
				
			}
			//System.out.println("Total columns: "+rsmd.getColumnCount());  
				//System.out.println("Column Name of 1st column: "+rsmd.getColumnName(1));  
				//System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(1));
			
			
			//Step5: close connection
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
		