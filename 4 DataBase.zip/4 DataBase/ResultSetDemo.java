import java.sql.*;  
class ResultSetDemo
{  
	public static void main(String args[])
	{  
	 try{  
		Class.forName("com.mysql.jdbc.Driver");

		String url= "jdbc:mysql://localhost:3306/ajay";
		String user="root";
		String pass="root";
		
		Connection con=DriverManager.getConnection(url,user,pass);  
  
		PreparedStatement ps=con.prepareStatement("select * from employee");  
		ResultSet rs=ps.executeQuery();  
		ResultSetMetaData rsmd=rs.getMetaData();  
  
		System.out.println("Total columns: "+rsmd.getColumnCount());  
		System.out.println("Column Name of 1st column: "+rsmd.getColumnName(1));  
		System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(1));  
  
		con.close();  
		}
		catch(Exception e)
		{ 
		System.out.println(e);
		}  
	}  
}  