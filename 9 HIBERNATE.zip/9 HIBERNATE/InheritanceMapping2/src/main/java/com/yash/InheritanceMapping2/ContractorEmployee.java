package com.yash.InheritanceMapping2;

public class ContractorEmployee extends Employee {

	private int duration;
	private int payPerHour;
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public int getPayPerHour() {
		return payPerHour;
	}
	public void setPayPerHour(int payPerHour) {
		this.payPerHour = payPerHour;
	}
	
}
